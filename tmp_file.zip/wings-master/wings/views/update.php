<p>Want to update your version of wings?</p>

<div><a href="<?=link_to('/admin/update_confirm')?>" class="ui button">Update now</a></div>
