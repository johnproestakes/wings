<?php
if(is_callable($plugin->attr['function']))
call_user_func($plugin->attr['function']);
  ?>
