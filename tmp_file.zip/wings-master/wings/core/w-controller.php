<?php if(!defined('ENVIRONMENT')) die('No direct script access');

class Wings_Controller {
  public function index(){
    echo "there is no index file associated with this controller";
  }
  function __construct(){}
  function __distruct(){}

}

class Wings_AdminController {
  public function index(){
    echo "there is no index file associated with this controller";
  }
  function __construct(){}
  function __distruct(){}

}

class Wings_ErrorHandler {
  public function index(){
    echo "Page Not Found";
  }
  function __construct(){}
  function __distruct(){}

}
