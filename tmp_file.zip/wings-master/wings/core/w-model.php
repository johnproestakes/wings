<?php if(!defined('ENVIRONMENT')) die('No direct script access');

class Wings_Model {
  function __construct(){}
  function __distruct(){}
}
