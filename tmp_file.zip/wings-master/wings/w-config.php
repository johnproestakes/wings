<?php //does not require direct script access refusal.

//switch base url
define('ENVIRONMENT', 'development');

//define application path
define('APPLICATION_PATH', 'application');

//update this field to accurately route requests
// $config['router_basepath'] = "/";
